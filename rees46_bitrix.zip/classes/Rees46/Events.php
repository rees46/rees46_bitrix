<?php
namespace Rees46;
use Rees46\Bitrix\Data;
class Events

{
	/**
	 * push view event
	 *
	 * @param $item_id
	 */
	public static function view($item_id)
	{
		$item = Data::getItemArray($item_id, false, true);
		Functions::jsPushData('view', $item);
	}


     //add order
     public static function OnSaleOrderSavedHandler(\Bitrix\Main\Event $event)
    {
        $parameters = $event->getParameters();
        $order = $parameters['ENTITY'];
        $order_id = $order->getId();
        $order_price = (float)($order->getPrice());
        $products = [];
        foreach (Data::getOrderItems($order_id) as $item) {
            $products[]= (object)([
                'id' => $item['PRODUCT_ID'],
                'amount'  => (int)$item['QUANTITY'],
                'price' => (float)$item['PRICE']
            ]);
        }
        $order_data = (object)(["products" => $products, "order_price" => $order_price, "order" => (is_string($order_id) ? $order_id : json_encode($order_id))]);
        Functions::cookiePushData('purchase', $order_data);
    }

     // basket
    public static function  OnSaleBasketItemMy(\Bitrix\Main\Event $event)
    {
        Functions::cookiePushData('cart', Data::getCurrentCart());
    }
} 
