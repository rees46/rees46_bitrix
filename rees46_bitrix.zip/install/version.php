<?php
$arModuleVersion = array(
	'VERSION' => '3.0.6',
	'VERSION_DATE' => '2019-08-16 12:12:00',
);
