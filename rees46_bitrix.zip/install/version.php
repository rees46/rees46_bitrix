<?php
$arModuleVersion = array(
	'VERSION' => '3.1.4',
	'VERSION_DATE' => '2020-04-30 15:04:15',
);
