<?php
$arModuleVersion = array(
	'VERSION' => '3.1.3',
	'VERSION_DATE' => '2019-11-28 17:06:16',
);
