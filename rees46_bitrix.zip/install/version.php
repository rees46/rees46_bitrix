<?php
$arModuleVersion = array(
	'VERSION' => '3.0.7',
	'VERSION_DATE' => '2019-08-21 12:00:21',
);
