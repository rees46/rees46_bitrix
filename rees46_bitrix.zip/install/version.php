<?php
$arModuleVersion = array(
	'VERSION' => '3.0.9',
	'VERSION_DATE' => '2019-10-02 16:06:12',
);
