<?php

$this->IncludeComponentTemplate();
