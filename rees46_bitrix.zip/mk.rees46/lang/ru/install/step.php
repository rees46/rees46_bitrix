<?php

$MESS['REES_MODULE_INSTALLED'] = 'Модуль REES46 установлен';
