<?php

$MESS['REES_MODULE_UNINSTALLED'] = 'Модуль успешно удален из системы';
