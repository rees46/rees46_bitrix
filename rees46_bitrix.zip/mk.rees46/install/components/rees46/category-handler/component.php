<?php

$this->IncludeComponentTemplate();
