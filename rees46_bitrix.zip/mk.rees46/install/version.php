<?php
$arModuleVersion = array(
	'VERSION' => '3.1.6',
	'VERSION_DATE' => '2022-06-02 17:56:22',
);
