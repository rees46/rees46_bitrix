<?php
$arModuleVersion = array(
	'VERSION' => '3.1.5',
	'VERSION_DATE' => '2022-05-27 15:35:35',
);
